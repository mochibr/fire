<?php
// First array with 11 unique players
$array1 = array('Player1', 'Player2', 'Player3', 'Player4', 'Player5', 'Player6', 'Player7', 'Player8', 'Player9', 'Player10', 'Player11');

// Second array with 11 unique players
$array2 = array('Player12', 'Player13', 'Player14', 'Player15', 'Player16', 'Player17', 'Player18', 'Player19', 'Player20', 'Player21', 'Player22');

// Captains and vice captains
$captain1 = 'Player1';
$viceCaptain1 = 'Player2';
$captain2 = 'Player12';
$viceCaptain2 = 'Player13';

// Generate 10 unique teams
$teams = array();
for ($i = 0; $i < 10; $i++) {
    $team = array();
    // Select 5 players from array1
    shuffle($array1); // shuffle the array to get random players
    $team = array_merge($team, array_slice($array1, 0, 5));
    // Select 6 players from array2
    shuffle($array2);
    $team = array_merge($team, array_slice($array2, 0, 6));
    // Add captain and vice captain
    $team[] = $captain1;
    $team[] = $viceCaptain1;
    $team[] = $captain2;
    $team[] = $viceCaptain2;
    // Remove duplicates and sort the team
    $team = array_unique($team);
    sort($team);
    // Add team to teams array
    $teams[] = $team;
}

// Display teams in a table
echo '<table border="1">';
echo '<tr><th>Team</th><th>Players</th></tr>';
foreach ($teams as $index => $team) {
    echo '<tr>';
    echo '<td>Team '.($index+1).'</td>';
    echo '<td>'.implode(', ', $team).'</td>';
    echo '</tr>';
}
echo '</table>';
?>
