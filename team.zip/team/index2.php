<?php

// First array with 5 players
$team1 = array('Player1', 'Player2', 'Player3', 'Player4', 'Player5');

// Second array with 6 players
$team2 = array('Player6', 'Player7', 'Player8', 'Player9', 'Player10', 'Player11');

// Function to get a random player and remove them from the array
function getRandomPlayer(&$array) {
    $randomIndex = array_rand($array);
    $player = $array[$randomIndex];
    unset($array[$randomIndex]);
    $array = array_values($array);
    return $player;
}

// Function to get a random captain and vice captain from a team
function getRandomCaptainAndViceCaptain($team) {
    $captain = getRandomPlayer($team);
    $viceCaptain = getRandomPlayer($team);
    return array('captain' => $captain, 'vice_captain' => $viceCaptain);
}

// Create 10 teams with 11 unique players, one captain and one vice captain each
$teams = array();
for ($i = 1; $i <= 10; $i++) {
    // Shuffle the two arrays
    shuffle($team1);
    shuffle($team2);
    // Get the first 5 players from the first array and the first 6 players from the second array
    $players = array_merge(array_slice($team1, 0, 5), array_slice($team2, 0, 6));
    // Get a random captain and vice captain from the players array
    $captains = getRandomCaptainAndViceCaptain($players);
    // Add the team to the teams array
    $teams[] = array('team_number' => $i, 'players' => $players, 'captain' => $captains['captain'], 'vice_captain' => $captains['vice_captain']);
}

// Display the teams in a table
echo '<table>';
echo '<thead><tr><th>Team Number</th><th>Players</th><th>Captain</th><th>Vice Captain</th></tr></thead>';
echo '<tbody>';
foreach ($teams as $team) {
    echo '<tr>';
    echo '<td>' . $team['team_number'] . '</td>';
    echo '<td>' . implode(', ', $team['players']) . '</td>';
    echo '<td>' . $team['captain'] . '</td>';
    echo '<td>' . $team['vice_captain'] . '</td>';
    echo '</tr>';
}
echo '</tbody>';
echo '</table>';

?>
