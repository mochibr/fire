<?php

// Two arrays of 11 unique players
$team1 = ['player1', 'player2', 'player3', 'player4', 'player5', 'player6', 'player7', 'player8', 'player9', 'player10', 'player11'];
$team2 = ['player12', 'player13', 'player14', 'player15', 'player16', 'player17', 'player18', 'player19', 'player20', 'player21', 'player22'];

// Shuffle the players in each array
shuffle($team1);
shuffle($team2);

// Assign captain and vice-captain for each team
$captain1 = array_pop($team1);
$vice_captain1 = array_pop($team1);
$captain2 = array_pop($team2);
$vice_captain2 = array_pop($team2);

// Generate 10 teams with 11 unique players each
for ($i = 1; $i <= 10; $i++) {
  // Select 5 players from team1 and 6 players from team2
  $players1 = array_slice($team1, 0, 5);
  $players2 = array_slice($team2, 0, 6);

  // Combine the players from both teams and shuffle them
  $players = array_merge($players1, $players2);
  shuffle($players);

  // Assign captain and vice-captain to the team
  $team_captain = ($i % 2 == 1) ? $captain1 : $captain2;
  $team_vice_captain = ($i % 2 == 1) ? $vice_captain1 : $vice_captain2;

  // Output the team and its players in a table
  echo '<table>';
  echo '<tr><th colspan="3">Team '.$i.'</th></tr>';
  echo '<tr><th>Player</th><th>Captain</th><th>Vice Captain</th></tr>';
  foreach ($players as $player) {
    $is_captain = ($player == $team_captain) ? 'Yes' : 'No';
    $is_vice_captain = ($player == $team_vice_captain) ? 'Yes' : 'No';
    echo '<tr><td>'.$player.'</td><td>'.$is_captain.'</td><td>'.$is_vice_captain.'</td></tr>';
  }
  echo '</table>';
  echo '<br>';
}

?>
