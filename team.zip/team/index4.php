<?php
// First array with 11 players
$array1 = array('player1', 'player2', 'player3', 'player4', 'player5', 'player6', 'player7', 'player8', 'player9', 'player10', 'player11');

// Second array with 11 players
$array2 = array('player12', 'player13', 'player14', 'player15', 'player16', 'player17', 'player18', 'player19', 'player20', 'player21', 'player22');

// Shuffle the arrays to get a random selection of players
shuffle($array1);
shuffle($array2);

// Create an empty array to store the teams
$teams = array();

// Create 10 unique teams with 11 players each
for ($i = 1; $i <= 10; $i++) {
    $team = array();

    // Add the first 5 players from the shuffled first array
    $team = array_merge($team, array_slice($array1, 0, 5));

    // Add the first 6 players from the shuffled second array
    $team = array_merge($team, array_slice($array2, 0, 6));

    // Remove the selected players from the original arrays to ensure uniqueness
    $array1 = array_diff($array1, $team);
    $array2 = array_diff($array2, $team);

    // Add a captain and vice-captain to the team
    $team[] = 'Captain';
    $team[] = 'Vice Captain';

    // Add the team to the list of teams
    $teams[] = $team;
}

// Display the team data in an HTML table
echo '<table border="1">';
echo '<tr><th>Team</th><th>Players</th></tr>';
foreach ($teams as $index => $team) {
    echo '<tr><td>Team '.($index+1).'</td><td>'.implode(', ', $team).'</td></tr>';
}
echo '</table>';
?>
