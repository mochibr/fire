<?php

$color_arr = array("Red", "Blue", "Green", "Yellow", "Orange","Pink");
echo "My favorite colors are ". $color_arr[0].", ".$color_arr[1].", ".$color_arr[2].", ".$color_arr[3];
echo"<pre>";
print_r($color_arr);

?>