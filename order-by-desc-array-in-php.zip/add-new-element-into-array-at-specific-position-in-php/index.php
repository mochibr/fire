<?php

$color_arr = array("Red", "Blue", "Yellow", "Orange","Pink");
array_splice( $color_arr, 3, 0, "Green");
echo"<pre>";
print_r($color_arr);

?>