<?php

$value_arr = array(5,10,15,25,30);
echo array_sum($value_arr);

?>