<?php

$color_arr = array("Red", "Blue", "Green", "Yellow", "Orange","Pink");
$new = array_map('strtolower',$color_arr);
// $new = array_map('strtoupper',$color_arr);
echo"<pre>";
print_r($new);

?>