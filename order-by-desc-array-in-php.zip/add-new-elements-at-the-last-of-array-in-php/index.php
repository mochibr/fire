<?php

$color_arr = array("Red", "Blue", "Green", "Yellow");
array_push($color_arr, "Orange","Pink");
echo"<pre>";
print_r($color_arr);

?>