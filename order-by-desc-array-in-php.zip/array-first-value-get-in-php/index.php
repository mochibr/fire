<?php

$color_arr = array("Red", "Blue", "Green", "Yellow", "Orange","Pink");
$first = current($color_arr);
echo $first;
echo"<pre>";
print_r($first);

?>