<?php

$color_arr = array("r" => "Red", "b" => "Blue", "g" => "Green", "y" => "Yellow", "p" => "Pink");
echo $color_arr["r"];
echo"<pre>";
print_r($color_arr);

?>