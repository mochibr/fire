<?php

$color_arr = array(
    array("Red", "Blue"),
    array("Green", "Yellow"),
    array("Orange","Pink")
);
echo"<pre>";
print_r($color_arr);

?>