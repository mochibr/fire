<?php

$name = array("Kelly", "Mark", "John", "Scott");
$age = array(25, 30, 45, 35);
$new = array_combine($name,$age);
echo"<pre>";
print_r($new);

?>