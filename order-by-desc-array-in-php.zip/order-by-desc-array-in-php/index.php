<?php

$color_arr = array("Red", "Blue", "Green", "Yellow", "Orange","Pink");
rsort($color_arr);
echo"<pre>";
print_r($color_arr);

?>