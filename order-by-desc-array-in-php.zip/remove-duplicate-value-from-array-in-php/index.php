<?php

$color_arr = array("Red", "Blue", "Blue", "Red", "Pink","Pink");
$new = array_unique($color_arr);
echo"<pre>";
print_r($new);

?>