<?php

$color_arr = array("r" => "Red", "b" => "Blue", "g" => "Green", "y" => "Yellow", "o" => "Orange", "p" => "Pink");
$new = array_flip($color_arr);
echo"<pre>";
print_r($new);

?>