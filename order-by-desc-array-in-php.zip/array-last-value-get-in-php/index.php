<?php

$color_arr = array("Red", "Blue", "Green", "Yellow", "Orange","Pink");
$last = end($color_arr);
echo $last;
echo"<pre>";
print_r($last);

?>