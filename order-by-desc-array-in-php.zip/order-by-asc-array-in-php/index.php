<?php

$color_arr = array("Red", "Blue", "Green", "Yellow", "Orange","Pink");
sort($color_arr);
echo"<pre>";
print_r($color_arr);

?>