<?php

$color_arr = array("r" => "Red", "b" => "Blue", "g" => "Green", "y" => "Yellow", "p" => "Pink");
extract($color_arr);
echo $r;
// echo"<pre>";
// print_r($color_arr);

?>