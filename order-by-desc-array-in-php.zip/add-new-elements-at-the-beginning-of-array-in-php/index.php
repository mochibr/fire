<?php

$color_arr = array("Green", "Yellow", "Orange","Pink");
array_unshift($color_arr, "Red", "Blue");
echo"<pre>";
print_r($color_arr);

?>