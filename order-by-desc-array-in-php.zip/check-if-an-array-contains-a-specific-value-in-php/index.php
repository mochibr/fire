<?php

$color_arr = array("Red", "Blue", "Green", "Yellow", "Orange","Pink");
// echo"<pre>";
// print_r($color_arr);
if(in_array("Red",$color_arr))
{
    echo "Match found";
}else{
    echo "Match not found";
}


?>