<!DOCTYPE html>
<html lang="en">

<head>
    <title>preview and remove image before upload using jQuery, PHP and MySQL</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <style>
        .upload_files {
            box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
            padding: 70px 0px;
        }

        .file_grid {
            position: relative;
            display: inline-block;
            width: 14%;
            margin-right: 14px;
            min-height: 56px;
        }

        .file_input {
            display: block;
            height: 115px;
            width: 100% !important;
            margin-right: 10px;
            z-index: 1;
            opacity: 0;
        }

        .img-upload img {
            position: absolute;
            top: 0;
            left: 0;
            box-shadow: rgb(0 0 0 / 24%) 0px 3px 8px;
        }

        .preview_info {
            position: absolute;
            top: 0;
        }

        .preview_info img {
            width: 180px;
            height: 115px;
            object-fit: cover;
            z-index: 1;
        }

        span.remove_preview {
            cursor: pointer;
            position: absolute;
            right: -5px;
            top: -9px;
            font-size: 10px;
            width: 20px;
            height: 20px;
            background: #f9423a;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            line-height: 10px;
            color: #fff;
            z-index: 1;
        }
    </style>
</head>

<body>

    <div class="container mt-5 text-center">
        <h2 class="mb-4">Preview and remove image before upload using jQuery, PHP and MySQL</h2>
        <div class="form-row mb-3">
            <div class="upload_files">
                <form id="multiple_upload_from" method="post" enctype="multipart/form-data">
                    <div class="input-group file_grid">
                        <div class="img-upload">
                            <img src="images/upload.png">
                        </div>
                        <input class="form-control file_input" type="file" name="multiple_upload[]" id="image1">
                        <div class="preview_info"></div>
                    </div>
                    <div class="input-group file_grid">
                        <div class="img-upload">
                            <img src="images/upload.png">
                        </div>
                        <input class="form-control file_input" type="file" name="multiple_upload[]" id="image2">
                        <div class="preview_info"></div>
                    </div>
                    <div class="input-group file_grid">
                        <div class="img-upload">
                            <img src="images/upload.png">
                        </div>
                        <input class="form-control file_input" type="file" name="multiple_upload[]" id="image3">
                        <div class="preview_info"></div>
                    </div>
                    <div class="input-group file_grid">
                        <div class="img-upload">
                            <img src="images/upload.png">
                        </div>
                        <input class="form-control file_input" type="file" name="multiple_upload[]" id="image4">
                        <div class="preview_info"></div>
                    </div>
                    <div class="mt-5">
                        <input type="submit" name="upload" class="btn btn-primary" value="Upload" />
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>

<script>
    /******************* Start Preview Image Muliple****************************/
    function preview_img() {
        var $input = $(this);
        var showImage = $(this).next(".preview_info");
        if (this.files && this.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                showImage.html('<span class="remove_preview"><i class="fa fa-close"></i></span><img src="' + e.target.result + '" />');
            }
            reader.readAsDataURL(this.files[0]);
        }
    }

    jQuery(document).on("change", "#image1", preview_img);
    jQuery(document).on("change", "#image2", preview_img);
    jQuery(document).on("change", "#image3", preview_img);
    jQuery(document).on("change", "#image4", preview_img);


    jQuery(document).on("click", ".remove_preview", function(e) {
        jQuery(this).parent(".preview_info").prev().val(null);
        jQuery(this).parent(".preview_info").html(null);
    });

    /******************* End Preview Image Muliple****************************/


    $('#multiple_upload_from').on('submit', function(event) {
        event.preventDefault();
        var file_input = $('.file_input').val();
        if (file_input == '') {
            alert("Please Select Image");
            return false;
        } else {
            $.ajax({
                url: "process.php",
                method: "POST",
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    $('#multiple_upload_from')[0].reset();
                    $(".preview_info").html(null);
                    console.log(data);
                }
            });
        }
    });
</script>

</html>