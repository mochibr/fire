<!DOCTYPE html>
<html lang="en">

<head>
    <title>preview and remove image before upload using jQuery, PHP and MySQL</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <style>
        .form-control {
            width: 100% !important;
            opacity: 0;
            height: 126px;
        }
        .input-group.file_grid img {
            width: 100%;
            min-height: 126px;
            height: 126px;
        }
        .input-group.file_grid {
            display: inline-block;
            vertical-align: top;
            width: 14%;
            margin-right: 2px;
            position: relative;
            min-height: 56px;
        }
        .preview_info {
            position: absolute;
            top: 0;
            left: 0;
            z-index: 999;
        }
        span.remove_preview {
            background: #f00;
            border-radius: 100%;
            width: 20px;
            height: 20px;
            z-index: 99999;
            top: -10px;
            right: -4px;
            position: absolute;
            color: #fff;

        }
        span.remove_preview:hover {
            background: #000;
        }
        span.remove_preview i {
            font-size: 12px;
            display: block;
            text-align: center;
            padding: 4px 0;
            cursor: pointer;
        }
        .img-upload {
            position: absolute;
        }
    </style>
</head>

<body>

    <div class="container mt-3">
        <h2>Table Head Colors</h2>
        <p>You can use any of the contextual classes to only add a color to the table header:</p>
        <div class="form-row mb-3">
            <label>Upload Image</label>
            <div class="input-group file_grid">
                <div class="img-upload">
                    <img src="images/upload.png">
                </div>
                <input class="form-control" type="file" name="image1" id="image1">
                <div class="preview_info"></div>
            </div>
            <div class="input-group file_grid">
                <div class="img-upload">
                    <img src="images/upload.png">
                </div>
                <input class="form-control" type="file" name="image2" id="image2">
                <div class="preview_info"></div>
            </div>
            <div class="input-group file_grid">
                <div class="img-upload">
                    <img src="images/upload.png">
                </div>
                <input class="form-control" type="file" name="image3" id="image3">
                <div class="preview_info"></div>
            </div>
            <div class="input-group file_grid">
                <div class="img-upload">
                    <img src="images/upload.png">
                </div>
                <input class="form-control" type="file" name="image4" id="image4">
                <div class="preview_info"></div>
            </div>
        </div>
    </div>

</body>

<script>
    /******************* Start Preview Image Muliple****************************/
    function preview_img() {
        var $input = $(this);
        var showImage = $(this).next(".preview_info");
        if (this.files && this.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                showImage.html('<span class="remove_preview"><i class="fa fa-close"></i></span><img src="' + e.target.result + '" />');
            }
            reader.readAsDataURL(this.files[0]);
        }
    }

    jQuery(document).on("change", "#image1", preview_img);
    jQuery(document).on("change", "#image2", preview_img);
    jQuery(document).on("change", "#image3", preview_img);
    jQuery(document).on("change", "#image4", preview_img);


    jQuery(document).on("click", ".remove_preview", function(e) {
        jQuery(this).parent(".preview_info").prev().val(null);
        jQuery(this).parent(".preview_info").html(null);
    });

    /******************* End Preview Image Muliple****************************/
</script>

</html>