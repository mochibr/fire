<?php
$conn = mysqli_connect("localhost", "root", "", "map");
// extract($_POST);

// echo"<pre>";
// print_r($_POST);

// if (isset($upload)) {
    $arr_files = array_map('array_filter', array_filter($_FILES['multiple_upload']));
	$remove_empty_arr = array_filter($arr_files);

    foreach($remove_empty_arr['name'] as $keys => $values)  
    {  
         if(move_uploaded_file($remove_empty_arr['tmp_name'][$keys], 'images/' . $values))  
         {  
              $output .= '<div class=col-md-3"><img src="upload/'.$values.'" class="img-responsive" /></div>';  
         }  
    } 

// }    

?>