<?php
//$conn = mysqli_connect("localhost", "debian-sys-maint", "Google@!123", "map");
$conn = mysqli_connect("localhost", "root", "", "map");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
 }