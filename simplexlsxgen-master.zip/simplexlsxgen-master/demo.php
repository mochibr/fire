<?php

//https://github.com/shuchkin/simplexlsxgen
require_once 'db.php';
require_once 'src/SimpleXLSXGen.php';

$query = "SELECT * from users ORDER BY id DESC";
$result = mysqli_query($conn, $query);
$arr = array();
$arr[] = array('ID', 'FIRST NAME', 'LAST NAME', 'City', 'COUNTRY', 'COUNTRY', 'CREATED', 'STATUS', 'STATUS', 'STATUS');
while ($row = mysqli_fetch_assoc($result)) {
    $arr[] = $row; 
}

$xlsx = Shuchkin\SimpleXLSXGen::fromArray($arr);
$xlsx->downloadAs('books.xlsx'); // or downloadAs('books.xlsx') or $xlsx_content = (string) $xlsx 