document.getElementById('tag-input').addEventListener('keypress', function(event) {
    const errorMessageElement = document.getElementById('error-message');
    
    if (event.key === 'Enter' && this.value.trim() !== '') {
        event.preventDefault(); 
        
        const tagText = this.value.trim().toLowerCase(); 
        
        // Check if the tag already exists
        const existingTags = document.querySelectorAll('.tags-input .tag span');
        let isDuplicate = false;
        existingTags.forEach(tag => {
            if (tag.textContent.toLowerCase() === tagText) {
                isDuplicate = true;
            }
        });
        
        // If tag is not a duplicate, add it
        if (!isDuplicate) {
            const tagBox = document.getElementById('tags-input-box');
            
            // Create tag element
            const tag = document.createElement('div');
            tag.classList.add('tag');
            tag.innerHTML = `<span>${tagText}</span><i class="remove-tag">&times;</i>`;
            
            // Append tag to the tags container
            tagBox.insertBefore(tag, this);

            // Reset input field and hide error message
            this.value = '';
            errorMessageElement.style.display = 'none';
            
            // Remove tag functionality
            tag.querySelector('.remove-tag').addEventListener('click', function() {
                this.parentElement.remove();
            });
        } else {
            // Show error message below the input
            errorMessageElement.textContent = 'Tag already exists!';
            errorMessageElement.style.display = 'block';
            this.value = ''; // Clear the input if it's a duplicate

            // Hide the error message after 2 seconds (2000ms)
            setTimeout(function() {
                errorMessageElement.style.display = 'none';
            }, 3000);
        }
    }
});

document.getElementById('submit-btn').addEventListener('click', function() {
    const tagElements = document.querySelectorAll('.tags-input .tag span');
    const errorMessageElement = document.getElementById('error-message');
    let tags = [];

    tagElements.forEach(tag => {
        tags.push(tag.textContent);
    });

    // Check if there are no tags
    if (tags.length === 0) {
        // Display an error message if no tags are added
        errorMessageElement.textContent = 'Please add at least one tag before submitting.';
        errorMessageElement.style.display = 'block';

        // Hide the error message after 3 seconds
        setTimeout(function() {
            errorMessageElement.style.display = 'none';
        }, 3000);
    } else {
        // Hide the error message if tags are present
        errorMessageElement.style.display = 'none';

        // Display the collected tag values in an alert
        alert('Tags: ' + tags.join(', '));
    }
});