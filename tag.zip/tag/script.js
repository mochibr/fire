document.addEventListener("DOMContentLoaded", function() {
    const customSelects = document.querySelectorAll(".custom-select");
    
    function updateSelectedOptions(customSelect) {
        const selectedOptions = Array.from(customSelect.querySelectorAll(".option.active"))
            .map(function(option) {
                return {
                    value: option.getAttribute("data-value"),
                    text: option.textContent.trim()
                };
            });

        const selectedValues = selectedOptions.map(function(option) {
            return option.value;
        });

        customSelect.querySelector(".tags_input").value = selectedValues.join(', ');

        let tagsHTML = "";

        if (selectedOptions.length === 0) {
            tagsHTML = '<span class="tag placeholder">Select the tags</span>';
        } else {
            const maxTagsToShow = 3; // Maximum tags to show directly
            let additionalTagsCount = 0; // Count of additional tags

            selectedOptions.forEach(function(option, index) {
                if (index < maxTagsToShow) {
                    tagsHTML += '<span class="tag">' + option.text + '<span class="remove-tag" data-value="' + option.value + '">&times;</span></span>';
                } else {
                    additionalTagsCount++;
                }
            });

            if (additionalTagsCount > 0) {
                tagsHTML += '<span class="tag">+' + additionalTagsCount + '</span>';
            }
        }

        customSelect.querySelector(".selected-options").innerHTML = tagsHTML;

    }

    // Toggle active class on option click
    customSelects.forEach(function(customSelect) {
        const options = customSelect.querySelectorAll(".option");
        options.forEach(function(option) {
            option.addEventListener("click", function() {
                option.classList.toggle("active");
                updateSelectedOptions(customSelect);
            });
        });
    });

    // Remove tag when close icon is clicked
    document.addEventListener("click", function(event) {
        const removeTag = event.target.closest(".remove-tag");
        if (removeTag) {
            const customSelect = removeTag.closest(".custom-select");
            const valueToRemove = removeTag.getAttribute("data-value");
            const optionToRemove = customSelect.querySelector(".option[data-value='" + valueToRemove + "']");
            optionToRemove.classList.remove("active");
            updateSelectedOptions(customSelect);
        }
    });

    const selectBoxes = document.querySelectorAll(".select-box");
    selectBoxes.forEach(function(selectBox) {
        selectBox.addEventListener("click", function() {
            selectBox.parentNode.classList.toggle("open");
        });
    });

    document.addEventListener("click", function(event) {
        if (!event.target.closest(".custom-select")) {
            customSelects.forEach(function(customSelect) {
                customSelect.classList.remove("open");
            });
        }
    });

    // Initial update of selected options on page load
    updateSelectedOptions(customSelects[0]);

    const submitButton = document.querySelector(".btn_submit");
    submitButton.addEventListener("click", function() {
        let valid = true;

        customSelects.forEach(function(customSelect) {
            const tagsInput = customSelect.querySelector(".tags_input");
            const selectedOptions = customSelect.querySelectorAll(".option.active");

            if (selectedOptions.length === 0) {
                tagsInput.classList.add("error");
                const tagErrorMsg = customSelect.querySelector(".tag_error_msg");
                tagErrorMsg.textContent = "This field is required";
                tagErrorMsg.style.display = "block";
                valid = false;
            } else {
                tagsInput.classList.remove("error");
                const tagErrorMsg = customSelect.querySelector(".tag_error_msg");
                tagErrorMsg.textContent = "";
                tagErrorMsg.style.display = "none";
            }
        });

        if (valid) {
            alert("Submitted");
            return;
        }
    });
});