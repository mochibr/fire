function updateProgressBar() {
    const scrollTop = $(window).scrollTop();
    const scrollHeight = $(document).height();
    const clientHeight = $(window).height();

    const scrollPercentage = (scrollTop / (scrollHeight - clientHeight)) * 100;

    $("#progressBar").css("width", `${scrollPercentage}%`);
}
$(document).on("scroll", updateProgressBar);