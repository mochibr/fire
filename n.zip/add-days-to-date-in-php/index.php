<?php
$date = "2023-02-16";
echo date('Y-m-d', strtotime($date. ' + 30 days'));