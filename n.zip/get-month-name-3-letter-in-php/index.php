<?php

$current_date_time = date('m/d/Y h:i:s a', time());
$month = date("M",strtotime($current_date_time));
echo $month;

?>