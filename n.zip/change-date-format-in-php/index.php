<?php

$current_date_time = date('m/d/Y h:i:s a', time());
$date = date("d-F-Y",strtotime($current_date_time));
echo $date;

?>