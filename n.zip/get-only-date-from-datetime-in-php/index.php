<?php

$current_date_time = date('m/d/Y h:i:s a', time());
$date = date("Y-m-d",strtotime($current_date_time));
echo $date;

?>