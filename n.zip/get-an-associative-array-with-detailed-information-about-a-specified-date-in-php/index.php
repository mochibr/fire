<?php

$current_date_time = date('m/d/Y h:i:s a', time());
$parse = date_parse($current_date_time);
echo"<pre>";
print_r($parse);

?>