<?php

$current_date_time = date('m/d/Y h:i:s a', time());
$date = date("l",strtotime($current_date_time));
echo $date;

?>