<?php
$number = range(0,5);
echo"<pre>";
print_r ($number);
