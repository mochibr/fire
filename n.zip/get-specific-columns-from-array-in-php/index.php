<?php

$users_arr = array(
    array(
        'id' => 1,
        'name' => 'Pardeep',
        "country" => "India"
    ),
    array(
        'id' => 2,
        'name' => 'Max',
        "country" => "Australia"
    ),
    array(
        'id' => 3,
        'name' => 'Sofia',
        "country" => "Brazil"
    ),
    array(
        'id' => 4,
        'name' => 'Tim',
        "country" => "Germany"
    )
);

$single_column_arr = array_column($users_arr, 'name');
echo"<pre>";
print_r($single_column_arr);