<?php
$date1 = date_create('2022-12-01');
$date2 = date_create('2023-02-18');
$diff = date_diff($date1, $date2);
echo $diff->format("%R%a days");