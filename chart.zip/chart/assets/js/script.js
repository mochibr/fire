$(document).ready(function () {
  calculateSum();

  function calculateSum() {
    // Initialize values outside the loop
    var valueP1 = 0;
    var valueP2 = 0;
    var valueP3 = 0;

    // Loop through each row in tbody
    $(".table_price tbody tr").each(function () {
      // Loop through each cell with class 'p1' in the row
      $(this)
        .find("td.p1")
        .each(function (index, element) {
          // Convert the text to a number and add it to the corresponding sum
          valueP1 += parseFloat($(element).text()) || 0;
        });

      // Loop through each cell with class 'p2' in the row
      $(this)
        .find("td.p2")
        .each(function (index, element) {
          // Convert the text to a number and add it to the corresponding sum
          valueP2 += parseFloat($(element).text()) || 0;
        });

      // Loop through each cell with class 'p3' in the row
      $(this)
        .find("td.p3")
        .each(function (index, element) {
          // Convert the text to a number and add it to the corresponding sum
          valueP3 += parseFloat($(element).text()) || 0;
        });

      // Update the tfoot cells with the calculated sums
      $(".t_p1").text(valueP1.toFixed(2));
      $(".t_p2").text(valueP2.toFixed(2));
      $(".t_p3").text(valueP3.toFixed(2));
    });

    // Calculate and update i_p1_sum
    var i_p1 = parseFloat($(".i_p1").text());
    var t_p1 = parseFloat($(".total .t_p1").text());
    var i_p1_sum = i_p1 - t_p1;
    $(".i_p1_sum").text(i_p1_sum.toFixed(2));
    $(".e_p2").text(Math.abs(i_p1_sum).toFixed(2));

    // Calculate and update i_p2_sum
    var i_p2 = parseFloat($(".i_p2").text());
    var t_p2 = parseFloat($(".total .t_p2").text());
    var i_p2_sum = i_p2 + t_p2;
    $(".i_p2_sum").text(i_p2_sum.toFixed(2));
    $(".e_p1").text(i_p2_sum.toFixed(2));

    // Calculate and update e_sum
    var e_p1 = parseFloat($(".e_p1").text());
    var e_p2 = parseFloat($(".e_p2").text());
    var e_sum = e_p1 - e_p2;
    $(".e_sum, .t_sum").text(e_sum.toFixed(2));
  }
});