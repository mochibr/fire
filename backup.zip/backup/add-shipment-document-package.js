/************************Start = Step 1 = Industry next button click show shipment details section**************************/

$(".industry_btn_next").click(function() {
    var selectedIndustry = $("#industry_type").val();
    if (selectedIndustry === null || selectedIndustry === "") {
      $("#industry_type_error_msg").text("This field is required");
    } else {
      $(".basic_details_ticks li:first").addClass("active");
      $("#industry_type_error_msg").text("");
      $("#shipment_details_section").slideDown();
      $(this).remove();
      let industryType = $("#industry_type").val();
      getIndustryData(industryType);
    }
});

/************************End = Step 1 = Industry next button click show shipment details section**************************/

/************************Start = Step 1 = Multiselect with serach add select shipment details section**************************/

$(document).ready(function() {

  $("#orgin_port").multiselect({
    numberDisplayed: 1,
    enableHTML: true,
    enableFiltering: true,
    enableFullValueFiltering: true,
    enableCaseInsensitiveFiltering: true,
    multiple: false   
  });

  $("#destinaton_port").multiselect({
    numberDisplayed: 1,
    enableHTML: true,
    enableFiltering: true,
    enableFullValueFiltering: true,
    enableCaseInsensitiveFiltering: true
  });

  jQuery(document).on("keyup", ".multiselect-search", function($) {

    var thisObj = this;
    setTimeout(function() {

      if (jQuery(thisObj).parent().parent().parent().find("li.multi-no-results").length == 0)
        jQuery(thisObj).parent().parent().parent().append('<li style="display:none" class="multi-no-results cropin-multi-select-noresult-lable"><a  href="#">No results matched ""</a></li>');

      var totalOptions = jQuery(thisObj).parent().parent().parent().parent().siblings().last().find("option").length;
      var totalFilteredOptins = totalOptions - jQuery(thisObj).parent().parent().parent().find("li.multiselect-filter-hidden").length;
      if (totalFilteredOptins <= 0) {
        jQuery(thisObj).parent().parent().parent().find("li.multi-no-results").find("a").text('No results matched');
        jQuery(thisObj).parent().parent().parent().find("li.multi-no-results").show();
      } else {
        jQuery(thisObj).parent().parent().parent().find("li.multi-no-results").hide();
      }
    }, 300);
  });

});


var countryList = [];

$('.country_of_origin:first option:gt(0)').each(function() {
    var obj = {};
    obj[$(this).val()] = $(this).text();
    countryList.push(obj);
});

$('.add_new_tr').on('click', function() {
  var newRowHTML = `
	<tr>
    <td>
      <div class="form-group">
        <div class="form_row">
          <input type="text" class="form-control entry_line" name="entry_line[]" placeholder="Entry Line">
        </div>
      </div>
    </td>
    <td>
      <div class="form-group">
        <div class="form_row">
          <input type="text" class="form-control hts_code" name="hts_code[]" placeholder="XXXX.XX.XXXX">
        </div>
      </div>
    </td>
    <td>
      <div class="form-group">
        <div class="form_row">
          <input type="text" class="form-control purchasehs_order" name="purchasehs_order[]" placeholder="Include Multiple Purchase Orders">
        </div>
      </div>
    </td>
    <td>
      <div class="form-group">
        <div class="form_row">
          <input type="text" class="form-control net_quantity" name="net_quantity[]" placeholder="Net Quantity">
        </div>
      </div>
    </td>
    <td>
      <div class="form-group">
        <div class="form_row">
          <select name="country_of_origin[]" class="form-select form-select-lg country_of_origin">
            <option value="">Select a Country</option>
          </select>
        </div>
      </div>
    </td>
    <td>
      <a href="javascript:void(0);" class="del_new_tr"><i class="fa fa-trash"></i></a>
    </td>
  </tr>
  `;

  
  var newTableRow = $(newRowHTML);

  $('.entry_line_file_info tbody').append(newTableRow);

  reArrangeIdInput();

  var selectElement = newTableRow.find('.country_of_origin');

  countryList.forEach(function(country) {
      var key = Object.keys(country)[0];
      var value = country[key];
      selectElement.append('<option value="' + key + '">' + value + '</option>');
  });
  
});

$(document).on('click', '.del_new_tr', function() {
  $(this).closest('tr').remove();
  reArrangeIdInput();
});

function reArrangeIdInput(){
  $(".entry_line_file_info tbody tr").each(function(index){
    $(this).find(".entry_line").attr("id", "entry_line_"+index);
    $(this).find(".hts_code").attr("id", "hts_code_"+index);
    $(this).find(".purchasehs_order").attr("id", "purchasehs_order_"+index);
    $(this).find(".net_quantity").attr("id", "net_quantity_"+index);
    $(this).find(".country_of_origin").attr("id", "country_of_origin_"+index);
});
}


function tabs(){
  $('#tab1').addClass('active-tab');
  $('.tab-button[data-tab="tab1"]').addClass('active');
  $('.tab-button').on('click', function(){
    $('.tab-button').removeClass('active');
    $(this).addClass('active');
    $('.tab-content').removeClass('active-tab');
    var tabId = $(this).data('tab');
    $('#' + tabId).addClass('active-tab');
  });
}

$(document).on("keyup", ".hts_code", function() {
  var numericValue = $(this).val().replace(/[^0-9]/g, '');

  if (numericValue.length > 4 && numericValue.length <= 6) {
      numericValue = numericValue.substring(0, 4) + '.' + numericValue.substring(4);
  } else if (numericValue.length > 6 && numericValue.length <= 8) {
      numericValue = numericValue.substring(0, 4) + '.' + numericValue.substring(4, 6) + '.' + numericValue.substring(6);
  } else if (numericValue.length > 8) {
      numericValue = numericValue.substring(0, 4) + '.' + numericValue.substring(4, 6) + '.' + numericValue.substring(6, 10);
  }

  $(this).val(numericValue);
});
/************************Start = Step 1 = Multiselect with serach add select shipment details section**************************/

function updatePreviewSection() {
  const previewSection = $(".bg-gray.mb-3.preview_section");

  previewSection.empty();
  let previewData = {};

  $("table tbody tr").each(function () {
    const checkboxLabel = $(this).find('.doc_label .document_title').val();
    const checkboxDocType = $(this).find('.doc_label .text_primary').val();
    const checkboxValue = $(this).find(".custom-select .option input[type='checkbox']:checked")
      .map(function () {
        return $(this).parent().text().trim();
      })
      .get()
      .join(", ");

    const fileInputs = $(this).find(".document_file_upload input[type='file']");
    const fileNamesArray = [];

    fileInputs.each(function () {
      const fileInput = this;
      const uploadTags = $(fileInput)
        .closest(".document_file_info")
        .find(".upload_tags")
        .val()
        .trim();

      if (fileInput.files.length > 0) {
        const selectedFiles = fileInput.files;
        const fileNames = [];

        // Loop through the selected files and retrieve their names
        for (let i = 0; i < selectedFiles.length; i++) {
          fileNames.push(selectedFiles[i].name);
        }

        fileNamesArray.push({
          upload_tags: uploadTags, // Assign the upload_tags value
          file_names: fileNames, // Assign the file names
        });
      } else {
        // Handle the case where there are no selected files for this input
        fileNamesArray.push({
          upload_tags: uploadTags, // Assign the upload_tags value
          file_names: [], // No file names
        });
      }
    });

    if ($(this).find('input[type="checkbox"]').prop("checked")) {
      const thText = $(this).closest("table").find("thead tr th").text().trim();

      if (!previewData[thText]) {
        previewData[thText] = [];
      }

      if (checkboxValue) {
        previewData[thText].push({ label: checkboxLabel, docType: checkboxDocType, values: checkboxValue, files: fileNamesArray });
      } else {
        previewData[thText].push({ label: checkboxLabel, docType: checkboxDocType, values: "", files: fileNamesArray });
      }
    }
  });

  const previewHeader = $("<h3>").text("Preview");
  const mainPreview = previewSection;
  mainPreview.append(previewHeader);
  
  for (const [thText, contentArray] of Object.entries(previewData)) {
    const previewContent = $('<div class="preview__info">').append(
      $("<p class='preview_category_title'>").text(thText.replace(/\d+\.\d+ /, ''))
    );

    const previewGroupWrap = $('<div class="preview_group_wrap">');
    let currentPreviewGroup = null;

    for (const contentObj of contentArray) {
      if (!currentPreviewGroup || currentPreviewGroup.label !== contentObj.label) {
        if (currentPreviewGroup) {
          previewGroupWrap.append(currentPreviewGroup.previewGroup);
        }

        currentPreviewGroup = {
          label: contentObj.label,
          previewGroup: $('<div class="preview_group">')
        };

        const contTypeParagraph = $("<p>").addClass("cont_type");
        if (contentObj.docType === "P") {
          contTypeParagraph.append($('<span class="text_primary">').text(contentObj.docType));
        } else {
          contTypeParagraph.append($('<span class="text_primary text_secondary">').text(contentObj.docType));
        }

        contTypeParagraph.append(" " + `<label>` + contentObj.label + `</label>`);
        currentPreviewGroup.previewGroup.append(contTypeParagraph);
      }

      if (contentObj.values !== "") {
        const valuesArray = contentObj.values.split(',').map(value => value.trim());

        const ulElement = $(`<div class="upload__file__name">`);

        valuesArray.forEach((value) => {
          if (value) {
            const liElement = `<div class="tags_info">
                <div class="tag_title">${value}</div>
                <ul data-cont-type="${contentObj.label + "_" + value}" class="upload__file__name">
                </ul>
            </div>`;
            ulElement.append(liElement);
          }
        });

        currentPreviewGroup.previewGroup.append(ulElement);
      }

      const arrayFileExits = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tiff', 'svg', 'doc', 'docx', 'rtf', 'pdf', 'xls', 'xlsx', 'txt', 'csv', 'html', 'xhtml', 'psd', 'sql', 'log', 'fla', 'xml', 'ade', 'adp', 'mdb', 'accdb', 'ppt', 'pptx', 'odt', 'ots', 'ott', 'odb', 'odg', 'otp', 'otg', 'odf', 'ods', 'odp', 'css', 'ai'];

      contentObj.files.forEach(fileItem => {
          fileItem.file_names.forEach((fileName, index)  => {
              const parts = fileName.split('.');
              if (parts.length > 1) {
                  const fileExt = parts[parts.length - 1].toLowerCase();
                  if (arrayFileExits.includes(fileExt)) {
                      const liElement = `
                          <li>
                              <div class="file-icon"><img src="/images/share/${fileExt}-icon.png" class="file-icon"></div>
                              <div class="file-name">${fileName}</div>
                          </li>`;
                      const ulSelector = `ul[data-cont-type="${contentObj.label + "_" + fileItem.upload_tags}"]`;
                      currentPreviewGroup.previewGroup.find(ulSelector).append(liElement);
                  }
              }
          });
      });
    
    }

    if (currentPreviewGroup) {
      previewGroupWrap.append(currentPreviewGroup.previewGroup);
    }

    previewContent.append(previewGroupWrap);
    mainPreview.append(previewContent);
  }

  previewSection.append(mainPreview);
}

updatePreviewSection();

  // Function to add a new row when "Add Secondary Document" is clicked
$(document).on("click", ".add_more", async function () {

    let industryType = $("#industry_type").val();
    let tagsOptions = ''; 
    const data = await $.ajax({
      type: "GET",
      url: "/company/get-tags",
      data: { industryType: industryType },
      dataType: 'json',
      success: function (data) {
        tagsOptions = data.map(tag => `
          <div class="option" data-value="${tag}">
            <input type="checkbox" hidden>${tag}
          </div>
        `).join('');

      },
      error: function (error) {
        console.error("Error fetching tags:", error);
      },
    });

    let upload_document_title = $(this).closest("table").find(".upload_document_title:first").val();
    let upload_document_title_id = $(this).closest("table").find(".upload_document_title_id:first").val();
    let upload_category_title_id = $(this).closest("table").find(".upload_category_title_id:first").val();
    let upload_category_title = $(this).closest("table").find(".upload_category_title:first").val();

    const newRow = `
      <tr class="disabled_tr">
        <td style="width: 254px;">
          <div class="document_info">
            <label class="doc_label label_secondary">
              <input type="text" class="text_primary text_secondary document_type" name="document_type[]" value="S" readonly>
              <input type="checkbox">
              <span class="checkmark"></span>
              <input type="text" class="form-control custom_title document_title upload_document_title" name="upload_document_title[]"/>
              <input type="text" class="upload_document_title_id" name="upload_document_title_id[]" value="0" hidden/>
              <input type="text" class="upload_category_title_id" name="upload_category_title_id[]" value="${upload_category_title_id}" hidden/>
              <input type="text" class="upload_category_title" name="upload_category_title[]" value="${upload_category_title}" hidden/>
              <span class="document_title_msg error"></span>
            </label>
          </div>
        </td>
        <td>
          <div class="custom-select">
            <div class="select-box">
              <input type="text" class="tags_input" name="tags[]" hidden/>
              <div class="selected-options"></div>
              <div class="arrow"><i class="fa fa-angle-down" aria-hidden="true"></i></div>
            </div>
            <div class="options">
              ${tagsOptions}
            </div>
            <spna class="tag_error_msg error"></spna>
            <a href="javascript:void(0);" class="remove_tr"><i class="fa fa-trash-o"></i></a>
          </div>
          <div class="upload_doc_info pt-2">
          </div>
        </td>
      </tr>
    `;
  
    $(this).closest("table").find("tbody").append(newRow);
    customeSelect();
});
  
  // Function to remove a row when "remove_tr" link is clicked
  $(document).on("click", ".remove_tr", function () {
    $(this).closest("tr").remove();
    updatePreviewSection();
  });

  $(document).on("keyup", ".document_title", function () {
    updatePreviewSection();
  });

function customeSelect() {
  // Function to update the selected options as tags with value greater than 3
  function updateSelectedOptions(selectIndex) {
    var customSelect = $(".custom-select").eq(selectIndex);
    var selectedOptions = customSelect
      .find(".option input:checked")
      .map(function () {
        return {
          value: $(this).parent().data("value"),
          text: $(this).parent().text().trim(),
        };
      })
      .get();

      var selectedValues = selectedOptions.map(function(option) {
        return option.value;
      });

      customSelect.find(".tags_input").val(selectedValues.join(', '));
    
      var tagsHTML = "";
      var uploadHTML = "";
      if (selectedOptions.length === 0) {
        tagsHTML = '<span class="placeholder">Select the tags</span>';
        customSelect.closest("tr").find(".upload_doc_info").html(null);
      } else {
        var maxTagsToShow = 3; // Maximum tags to show directly
        var additionalTagsCount = 0; // Count of additional tags

        selectedOptions.map(function(option, index) {
          if (index < maxTagsToShow) {
            tagsHTML += '<span class="tag">' + option.text + '<span class="remove-tag" data-value="' + option.value + '">&times;</span></span>';
          } else {
            additionalTagsCount++;
          }
        });

        if (additionalTagsCount > 0) {
          tagsHTML += '<span class="tag">+' + additionalTagsCount + '</span>';
        }

        
      }
    customSelect.find(".selected-options").html(tagsHTML);
  }


  $(".custom-select").each(function(index) {
    updateSelectedOptions(index);
  });

  updateSelectedOptions(0, $(".custom-select").eq(0));
}

  var selectedValues = [];
  $(document).on("click", ".option", function (e) {
    e.preventDefault();
    $(this).toggleClass("active");
    var customSelect = $(this).closest(".custom-select");
    var checkbox = $(this).find("input[type='checkbox']");
    
    // Toggle the checkbox status
    checkbox.prop("checked", !checkbox.prop("checked"));
    
    let option = $(this).data("value");
    var tr = customSelect.closest("tr");

    let entry = $(this).closest(".tab-content").attr("data-entry");
    let upload_document_title = tr.find(".upload_document_title").val().replace(/\s+/g, "_");
    let fileInputName = entry+"_"+upload_document_title + "_" + option.replace(/\s+/g, "_");
    
    // Check if the value is not already in the selectedValues array
    if (checkbox.is(':checked') && selectedValues.indexOf(option) === -1) {
      let uploadHTML = `<div class="document_file_info">
          <div class="document_file_tag"><input type="text" class="upload_tags" name="upload_tags[]" value="${option}" readonly=""></div>
          <div class="document_file_upload">
            <input type="file" class="form-control fileInput" name="${fileInputName.toLowerCase()}[]"  multiple="">
            <span class="upload_file_msg error"></span>
          </div>
        </div>`;
    
      customSelect.closest("tr").find(".upload_doc_info").append(uploadHTML);
      selectedValues.push(option);
    }else {
      var matchingElements = tr.find(".document_file_info").filter(function() {
        return $(this).find(".upload_tags").val() === option;
      }); 
      matchingElements.remove();
      selectedValues = selectedValues.filter(function(value) {
        return value !== option;
      });
    }
    
    customeSelect();
    updatePreviewSection();
    $(this).closest(".custom-select").removeClass("open");
  });


  $(document).on("click", ".remove-tag", function () {
    var customSelect = $(this).closest(".custom-select");
    var valueToRemove = $(this).data("value");
    var tr = customSelect.closest("tr");

    const optionToRemove = $(customSelect).find(".option[data-value='" + valueToRemove + "']");
    $(optionToRemove).removeClass("active");

    customSelect
    .find(
      ".option[data-value='" + valueToRemove + "'] input[type='checkbox']"
    )
    .prop("checked", false);

    var matchingElements = tr.find(".document_file_info").filter(function() {
      return $(this).find(".upload_tags").val() === valueToRemove;
    });

    matchingElements.remove();
    
    selectedValues = selectedValues.filter(function(value) {
      return value !== valueToRemove;
    });
    customeSelect();
    updatePreviewSection();
  });

  $(document).on(
    "click",
    ".document_info input[type='checkbox']",
    function () {
      const isCheckbox = $(this).is('input[type="checkbox"]:checked');
      const trElement = $(this).closest("tr");
      updatePreviewSection();
      if (!isCheckbox) {
        trElement.find(".upload_doc_info ").html(null);
        trElement.find(".custom-select .selected-options").html('<span class="tag placeholder">Select the tags</span>');
        trElement.find(".custom-select .options .option").find('input').prop("checked", false);
        trElement.addClass("disabled_tr");
      }else{
        trElement.removeClass("disabled_tr");
      }
      selectedValues = [];
    }
  );
  

  $(document).on("click", ".select-box", function () {
    if (!$(event.target).closest(".tag").length) {
      $(this).parent().toggleClass("open");
    }
  });

$(document).on("click", function (e) {
  if (!$(e.target).closest(".custom-select").length) {
    $(".custom-select").removeClass("open");
  }
});

function isTagChecked(document, tag) {
  if (document.exits_build_upload && document.exits_build_upload.tags) {
    const exitTags = document.exits_build_upload.tags.split(",");
    return exitTags.some(exitTag => exitTag.trim() === tag.trim());
  }
  return false;
}

function getIndustryData(industryType) {
  if (industryType !== "") {
    // Make an AJAX request to get the data
    $.ajax({
      url: "/company/get-industry-data",
      method: "GET",
      data: { industry_type: industryType },
      dataType: "json",
      success: function (data) {
        let leftHtml = "";
        let rightHtml = "";
        let previewHtml = "";

        leftHtml += `<ul>`;
        $.each(data.leftSection, function (categoryTitle, documents) {
          leftHtml += `
              <li>
                  <a href="javascript:void(0);">
                      <i class="fa fa-check-circle" aria-hidden="true"></i>
                      <span>${categoryTitle}</span>
                  </a>
              </li>
          `;
        });
        leftHtml += `</ul>`;

        let indexCounter = 1;
        let tableNone = "";
        $.each(data.rightSection, function (categoryTitle, documents) {

          if(indexCounter != 1){
            tableNone = `style="display:none;"`;
          }
          rightHtml += `
              <table ${tableNone}>
                  <thead>
                      <tr>
                          <th colspan="2">${categoryTitle}</th>
                      </tr>
                  </thead>
                  <tbody>
          `;

          $.each(documents, function (index, document) {
            let optionsHtml = "";
            if (document.tags) {
              const tags = document.tags.split(",");
              $.each(tags, function (tagIndex, tag) {
                optionsHtml += `
                    <div class="option" data-value="${tag}">
                        <input type="checkbox" hidden> ${tag}
                    </div>
                `;
              });
            }

          rightHtml += `
              <tr class="disabled_tr">
                  <td style="width: 254px;">
                      <div class="document_info">
                          <label class="doc_label">
                              <input type="text" class="text_primary document_type" name="document_type[]" value="P" readonly>
                              <input type="checkbox" />
                              <span class="checkmark"></span>
                              <span class="text_doc_title">${document.document.title}</span>
                              <input class="primary_input custom_title document_title upload_document_title" type="text" name="upload_document_title[]" value="${document.document.title}" hidden />
                              <input type="text" class="upload_document_title_id" name="upload_document_title_id[]" value="${document.document.document_title_id}" hidden/>
                              <input type="text" class="upload_category_title_id" name="upload_category_title_id[]" value="${document.document.category_title_id}" hidden/>
                              <input type="text" class="upload_category_title" name="upload_category_title[]" value="${document.document.category_title}" hidden/>
                              <span class="document_title_msg error"></span>
                          </label>
                      </div>
                  </td>
                  <td>
                      <div class="custom-select">
                          <div class="select-box">
                              <input type="text" class="tags_input" name="tags[]" hidden/>
                              <div class="selected-options"></div>
                              <div class="arrow"><i class="fa fa-angle-down" aria-hidden="true"></i></div>
                          </div>
                          <div class="options">
                              ${optionsHtml}
                          </div>
                          <spna class="tag_error_msg error"></spna>
                      </div>
                      <div class="upload_doc_info pt-2">
                       </div>
                  </td>
              </tr>
          `;
          });

          rightHtml += `
                  </tbody>
                  <tfoot>
                      <tr>
                          <td><a href="javascript:void(0);" class="add_more"><i class="fa fa-plus"></i> Add Secondary Document (Optional)</a></td>
                      </tr>
                  </tfoot>
              </table>
          `;
          indexCounter++;
        });

        rightHtml += `<div class="alert alert-danger" style="display: none;">Please check at least one checkbox in each table before proceeding.</div>
        <div class="col-lg-12 mt-3 d-flex justify-content-between align-items-center">
            <button type="button" class="btn btn-info-fill previous">Go Back</button>
            <button type="button" class="btn btn-info-fill next">Next</button>
        </div>`;

        $(".left_section").html(leftHtml);
        $(".right_section").html(rightHtml);

        var countBox = $(".countBox_wrap ul");
        var productSlider = $(".product_slider");
        // Clear the existing content
        countBox.empty();
        productSlider.empty();

        $.each(data.industrySupplyChainData, function (index, item) {
          var indexNumber = item.index;
          var title = item.title;
          countBox.append('<li><span>' + indexNumber + '. ' + title + '</span><b class="' + title.replace(' ', '') + '">0</b></li>');
          productSlider.append('<div class="box_container" data-indexslider="'+index+'"><div class="top_head"><h3>' + indexNumber + '. ' + title + '</h3><i class="addbox fas fa-plus-circle" data-class="' + title.replace(' ', '') + '"></i></div><div class="box_wrapp"></div></div>');
        });

        // $('.preview_section').html(previewHtml);
        initializeDragAndDrop();
        customeSelect();
      },
      error: function (error) {
        console.error(error);
      },
    });
  } else {
    // Clear the industry_data div if no option is selected
    $("#industry_data").html("");
  }
}

/***********************Start Build Map**************************/
// Add and remove box
$(document).on("click", ".addbox", function() {
	var dataClass = $(this).data('class'); // Get the data-class value
    var $boxContainer = $(this).closest(".box_container"); // Get the closest box_containe

	var $newBoxInfo = $(`<div class="box_info" draggable="true">

		<div class="box_header">
			<span class="entityText">Entity Name</span><div class="action_box"><i class="fas fa-caret-down"></i></div>
		</div>
		<div class="box_body">
		<div class="form_row mt-2">
			<input type="text" class="form-control ename" name="entity_name" placeholder="Entity Name">
		</div>
		<div class="form_row mt-2">
			<input type="text" class="form-control" name="address" placeholder="Address" >
		</div>
    <div class="form_row mt-2">
      <select name="country" class="form-select bulid_country">
        <option value="">Select Country</option>				
      </select>
    </div>
		<div class="form_row mt-2">
			<input type="text" class="form-control" name="remark" placeholder="Remark">
		</div>
    <div class="form_row row mt-2 data_range_picker">
      <label>Document Date Range</label>
      <div class="col-md-6">
        <input type="text" class="form-control start-date" placeholder="From" />
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control end-date" placeholder="To" />
      </div>
    </div>
		<div class="custom-select-map">
			<div class="select-box-map">
				<div class="selectedMap">
					Select options
				</div>
				<div class="options-container-map">
				</div>
			</div>
		</div>
		<ul class="selected_document"></ul>
		<div class="box_bottom">
			<span><i class="fas fa-save"></i></span>
			<span><i class="fas fa-trash"></i></span>
		</div> 
		</div>
	

</div>`); 

// Check if there's an existing .box_info element, and insert $newBoxInfo before it if it exists
var $existingBoxInfo = $boxContainer.find(".box_wrapp .box_info:first");
if ($existingBoxInfo.length > 0) {
  $existingBoxInfo.before($newBoxInfo);
} else {
  $boxContainer.find(".box_wrapp").append($newBoxInfo);
}


let fileArray = [];
$(".preview_section .tags_info ul li").each(function () {
  let title = $(this).find("div:eq(1)").text();
  let fileindex = $(this).find("div:eq(1)").attr("data-fileindex");
  let url = $(this).find("div:eq(1)").attr("data-url");
  if (title.trim() !== '') {
    fileArray.push({ title: title.trim(), fileindex, url });
  }
});

fileArray.forEach(fileData => {
  const { title, fileindex, url } = fileData;
  const iconSrc = getFileIconElement(title);

  const html = `<div class="option-map">
      <input type="checkbox" class="checkbox document_select_checkbox">
      <label class="label">
          <img src="${iconSrc}" alt="${title}">
          <span data-buildindex="${fileindex}" data-url="${url}">${title}</span>
      </label>
  </div>`;
  
  $newBoxInfo.find(".options-container-map").append(html);

});


// Update the count for the corresponding data-class
var $countElement = $(`.countBox_wrap .${dataClass}`);
var currentCount = parseInt($countElement.text());
$countElement.text(currentCount + 1);

// Hide other box_info elements inside box_container, show the first
$boxContainer.find('.box_info').not(':first').find(".box_body").hide();
$boxContainer.find('.box_info:first').find(".box_body").show();

var countryList = [];

$('#raw_country_origin option:gt(0)').each(function() {
    var obj = {};
    obj[$(this).val()] = $(this).text();
    countryList.push(obj);
});

var selectElement = $boxContainer.find('.bulid_country');
countryList.forEach(function(country) {
    var key = Object.keys(country)[0];
    var value = country[key];
    selectElement.append('<option value="' + key + '">' + value + '</option>');
});


var startDateInput = $newBoxInfo.find('.start-date');
var endDateInput = $newBoxInfo.find('.end-date');

startDateInput.datepicker({
    format: "dd-mm-yyyy",
    autoclose: true,
    todayHighlight: true
});

endDateInput.datepicker({
    format: "dd-mm-yyyy",
    autoclose: true,
    todayHighlight: true
});

startDateInput.on('changeDate', function (selected) {
    var startDate = new Date(selected.date.valueOf());
    endDateInput.datepicker('setStartDate', startDate);
});

endDateInput.on('changeDate', function (selected) {
    var endDate = new Date(selected.date.valueOf());
    startDateInput.datepicker('setEndDate', endDate);
});

initializeDragAndDrop();
});  

function initializeDragAndDrop() {
  const boxInfoElements = document.querySelectorAll('.box_info');
  let draggedElement = null;

  boxInfoElements.forEach((boxInfo) => {
      boxInfo.addEventListener('dragstart', (event) => {
          event.dataTransfer.setData('text/plain', boxInfo.classList);
          event.dataTransfer.effectAllowed = 'move';
          draggedElement = boxInfo; // Store the dragged element
          boxInfo.classList.add('dragging');
      });

      boxInfo.addEventListener('dragend', (event) => {
          boxInfo.classList.remove('dragging');
          updateCounts();
      });
  });

  const boxContainers = document.querySelectorAll('.box_container');

  boxContainers.forEach((boxContainer) => {
      boxContainer.addEventListener('dragover', (event) => {
          event.preventDefault();
          if (!boxContainer.classList.contains('dragover')) {
              boxContainer.classList.add('dragover');
          }
      });

      boxContainer.addEventListener('dragleave', () => {
          boxContainer.classList.remove('dragover');
      });

      boxContainer.addEventListener('drop', (event) => {
          event.preventDefault();
          boxContainer.classList.remove('dragover');
          if (draggedElement) {
              // Append the dragged element to the drop target
              boxContainer.querySelector('.box_wrapp').appendChild(draggedElement);
              draggedElement = null; // Reset the dragged element reference
          }
      });
  });
}

function updateCounts() {
  $(".addbox").each(function() {
        var dataClass = $(this).data('class');
        var count = $(this).closest(".box_container").find('.box_info').length;
        $(`.countBox_wrap .${dataClass}`).text(count);
    });

  $(".box_container").each(function(){
    let $boxContainer = $(this);
    $boxContainer.find('.box_info').not(':first').find(".box_body").hide();
    $boxContainer.find('.box_info:first').find(".box_body").show();
  });
}

$(document).on("click", ".box_header", function() {
  var $boxInfo = $(this).closest(".box_info");
  $boxInfo.siblings(".box_info").find(".box_body").slideUp();
  $boxInfo.find(".box_body").slideToggle();
});

$(document).on("click", ".box_bottom .fa-trash", function() {
  var $boxInfo = $(this).closest(".box_info");
  var $boxContainer = $(this).closest(".box_container").find(".addbox");
  var dataClass = $boxContainer.data('class'); // Get the data-class value of the removed box_info
  $boxInfo.remove();

  // Update the count for the corresponding data-class after removing the box_info
  var $countElement = $(`.countBox_wrap .${dataClass}`);
  var currentCount = parseInt($countElement.text());
  $countElement.text(currentCount - 1);
  updateCounts();
});

$(document).on("click", ".box_bottom .fa-save", function() {
  $(this).closest(".box_body").slideUp();
});

function slider() {
  var slideCount = $('.box_container').length;
  var slideWidth = $('.box_container').width();
  var animationDuration = 200;
  var currentIndex = 0;

  // Remove previous click event handlers to avoid multiple bindings
  $('.prev-btn').off('click');
  $('.next-btn').off('click');

  function moveLeft() {
      if (currentIndex === 0) {
          return; // Don't allow moving left when at the first slide
      }
      currentIndex--;
      updateButtonState();
      $('.product_slider').addClass('transition-class');
      $('.box_container:last').prependTo('.product_slider');
      $('.product_slider').css('left', -slideWidth);
      $('.product_slider').animate({
          left: 0
      }, animationDuration);
  }

  function moveRight() {
      if (currentIndex === slideCount - 1) {
          return; // Don't allow moving right when at the last slide
      }
      currentIndex++;
      updateButtonState();
      $('.product_slider').addClass('transition-class');
      $('.product_slider').animate({
          left: -slideWidth
      }, animationDuration, function () {
          $('.box_container:first').appendTo('.product_slider');
          $('.product_slider').css('left', 0);
      });
  }

  function updateButtonState() {
      if (currentIndex === 0) {
          $('.prev-btn').prop('disabled', true).addClass('slider_btn_disabled');;
      } else {
          $('.prev-btn').prop('disabled', false).removeClass('slider_btn_disabled');
      }

      if (currentIndex === slideCount - 3) {
          $('.next-btn').prop('disabled', true).addClass('slider_btn_disabled');;
      } else {
          $('.next-btn').prop('disabled', false).removeClass('slider_btn_disabled');
      }
  }

  $('.prev-btn').click(function () {
      moveLeft();
  });

  $('.next-btn').click(function () {
      moveRight();
  });

  updateButtonState();

  function rearrangeElementsByDataIndexSlider() {
      currentIndex = 0;
      updateButtonState();
      $('.product_slider').removeClass('transition-class');
      $('.product_slider').css('left', 0);

      $('.box_container').sort(function (a, b) {
          return +a.getAttribute('data-indexslider') - +b.getAttribute('data-indexslider');
      }).appendTo('.product_slider');
  }
  
  rearrangeElementsByDataIndexSlider();
}

$(document).on("keyup", ".box_container .ename", function() {
	var inputVal = $(this).val();
	var boxContainer = $(this).closest('.box_info');
	var entityTextElement = boxContainer.find('.entityText');
	if (inputVal === '') {
		entityTextElement.text('Entity Name');
	} else {
		entityTextElement.text(inputVal);
	}
});

$(document).on('click', '.custom-select-map', function(event) {
    event.stopPropagation(); // Prevent the click event from propagating

    const selectBox = $(this);
    const selectedMap = selectBox.find('.selectedMap');
    const optionsContainer = selectBox.find('.options-container-map');
    
    if (optionsContainer.hasClass('active')) {
        optionsContainer.removeClass('active');
    } else {
        optionsContainer.addClass('active');
    }

    // Handle clicks on options
    optionsContainer.on('click', '.option-map', function() {
        const checkbox = $(this).find('.checkbox');
        const label = $(this).find('.label');
        
        checkbox.prop('checked', !checkbox.prop('checked'));

        if (checkbox.prop('checked')) {
            label.parent().addClass('selected');
        } else {
            label.parent().removeClass('selected');
        }

        // Update the selectedMap text
        updateselectedMapValue(selectedMap, optionsContainer);
    });

    // Close options container when focus is lost
    optionsContainer.on('focusout', function() {
        optionsContainer.removeClass('active');
    });
});

// Click event handler for closing options container when clicking outside
$(document).on('click', function(event) {
  $('.custom-select-map').each(function() {
      const selectBox = $(this);
      const optionsContainer = selectBox.find('.options-container-map');
      
      if (optionsContainer.hasClass('active') && !selectBox.is(event.target) && selectBox.has(event.target).length === 0) {
          optionsContainer.removeClass('active');
      }
  });
});

function updateselectedMapValue(selectedMap, optionsContainer) {
  const checkboxes = optionsContainer.find('.checkbox');
  const labels = optionsContainer.find('.label span');
  const selectedMapValues = [];
  const selectedMapCount = checkboxes.filter(':checked').length;

  checkboxes.each(function(index) {
      if (checkboxes.eq(index).prop('checked')) {
          selectedMapValues.push(labels.eq(index).html().trim());
      }
  });

  if (selectedMapCount > 0) {
      if (selectedMapCount === 1) {
          selectedMap.html(selectedMapValues.join(', '));
      } else {
          selectedMap.html('+' + selectedMapCount + ' selected');
      }
  } else {
      selectedMap.html('Select options');
  }
}

$(document).on("click", ".document_select_checkbox", function() {
if ($(this).is(':checked')) {
  var htmlContent = $(this).closest('.option-map').find("label").html();
  var listItem = $('<li>').html(htmlContent);
  $('.selected_document').append(listItem);
  }
});

$(document).on("click", ".option-map", function() {
  var labelContent  = $(this).find("label").html();
var removeButton = '';
// var removeButton = '<span class="remove_map">&times;</span>';
  var listItemContent = labelContent + removeButton;
  var listItem = $('<li>').html(listItemContent);
  if ($(this).find(".document_select_checkbox").is(':checked')) {
      $(this).closest(".box_body").find('.selected_document').append(listItem);
  } else {
      var listItemText = $(listItem).text();
  $(this).closest(".box_body").find('.selected_document li:contains("' + listItemText + '")').remove();
  }
});

$(document).on("click", ".productionPreview", function() {
  $("#modalBuildProductionMap").modal("show");
  previewBuildProMap();

  /*$('.box_info').each(function() {
      var title = $(this).closest('.box_container').find('.top_head h3').text();
      var entityName = $(this).find('input[name="entity_name"]').val();
      var address = $(this).find('input[name="address"]').val();
      var remark = $(this).find('input[name="remark"]').val();
      var selected_options = [];
  
      $(this).find('.option-map input:checked').each(function() {
          var spanValue = $(this).siblings('label').find('span').text();
          selected_options.push(spanValue);
      });
  
      if (entityName.trim() !== '') {
          var item = {
              "title": title,
              "entity_name": entityName,
              "address": address,
              "remark": remark,
              "selected_options": selected_options
          };
  
          if (!buildProductionMap[title]) {
              buildProductionMap[title] = [];
          }
  
          // Check for duplicates and merge them
          var existingItem = buildProductionMap[title].find(existing => existing.entity_name === entityName);
          if (existingItem) {
              existingItem.selected_options = existingItem.selected_options.concat(selected_options);
          } else {
              buildProductionMap[title].push(item);
          }
      }
  });
  
  $('.box_container').each(function() {
      var title = $(this).find('.top_head h3').text()
      var entityName = $(this).find('input[name="entity_name"]').val();
  
      if (entityName !== '') {
          var item = {
              "title": title,
              "entity_name": entityName,
              "address": "",
              "remark": "",
              "selected_options": []
          };
  
          if (!buildProductionMap[title]) {
              buildProductionMap[title] = [];
          }
  
          // Check for duplicates and merge them
          var existingItem = buildProductionMap[title].find(existing => existing.entity_name === entityName);
          if (!existingItem) {
              buildProductionMap[title].push(item);
          }
      }
  });
  
  console.log(JSON.stringify(buildProductionMap, null, 3)); */


  
});

function previewBuildProMap(){
  
  var buildProductionMap = {};

  $('.box_info').each(function() {
      var title = $(this).closest('.box_container').find('.top_head h3').text().replace(/\d+\.\s*/, '');
      var entityName = $(this).find('input[name="entity_name"]').val();
      var address = $(this).find('input[name="address"]').val();
      var remark = $(this).find('input[name="remark"]').val();
      var selected_options = [];
  
      $(this).find('.option-map input:checked').each(function() {
          var spanValue = $(this).siblings('label').find('span').text();
          selected_options.push(spanValue);
      });
  
      if (entityName.trim() !== '') {
          var item = {
              "title": title,
              "entity_name": entityName,
              "address": address,
              "remark": remark,
              "selected_options": selected_options
          };
  
          if (!buildProductionMap[title]) {
              buildProductionMap[title] = [];
          }
  
          // Check for duplicates and merge them
          var existingItem = buildProductionMap[title].find(existing => existing.entity_name === entityName);
          if (existingItem) {
              existingItem.selected_options = existingItem.selected_options.concat(selected_options);
          } else {
              buildProductionMap[title].push(item);
          }
      }
  });
  
  $('.box_container').each(function() {
      var title = $(this).find('.top_head h3').text().replace(/\d+\.\s*/, '');
      var entityName = $(this).find('input[name="entity_name"]').val();
  
      if (entityName !== '') {
          var item = {
              "title": title,
              "entity_name": entityName,
              "address": "",
              "remark": "",
              "selected_options": []
          };
  
          if (!buildProductionMap[title]) {
              buildProductionMap[title] = [];
          }
  
          // Check for duplicates and merge them
          var existingItem = buildProductionMap[title].find(existing => existing.entity_name === entityName);
          if (!existingItem) {
              buildProductionMap[title].push(item);
          }
      }
  });

  /*var allowedTitles = ["Spinner", "Manufacture"];

  // Filter out titles that are not in the allowedTitles list
  for (var title in buildProductionMap) {
      if (!allowedTitles.includes(title)) {
          delete buildProductionMap[title];
      }
  }

  console.log(JSON.stringify(buildProductionMap, null, 3)); */

  if (Object.keys(buildProductionMap).length === 0) {
    $('.show_pop_up_map').html('<p>No data</p>');
  } else {
    const html1 = Object.entries(buildProductionMap)
    .map(([title, entities]) => `
      <div class="preview-map-wrap col-lg-4">
        <h2>${title}</h2>
        <div class="box_wrap">
        ${entities.map(entity => {
          if (entity.entity_name) {
            return `
              <div class="box-info">
                <div class="info-head">
                  <ul>
                    <li>Name: <strong>${entity.entity_name}</strong></li>
                    <li>Address: ${entity.address}</li>
                  </ul>
                </div>
                <div class="remark-info">
                  <p><b>Remark:</b>${entity.remark}</p>
                </div>
                <div class="document-info">
                  <div class="document_head">Documents<span class="document_count">${entity.selected_options.length}</span></div>
                  <ul class="preview_document">
                    ${entity.selected_options.map(option => `
                      <li>
                        <div class="inline_document">
                          <div class="file-icon">
                            <img src="/images/share/jpg-icon.png" class="file-icon">
                          </div>
                          ${option}
                        </div>
                      </li>
                    `).join('')}
                  </ul>
                </div>
              </div>
            `;
          } else {
            return '';
          }
        }).join('')}
        </div>
      </div>
    `)
    .join('');
  
    $('.show_pop_up_map').html(html1);
    }
  
}
/***********************End Build Map**************************/

$("#industry_type").change(function () {
  let industryType = $(this).val();
  getIndustryData(industryType);
});
  

$("#industry_type").change(function () {
  let industryType = $(this).val();
  getIndustryData(industryType);
});
$(document).ready(function () {
  var currentStep = 1;
  var totalSteps = $(".step").length;

  // Function to update the active step
  function updateActiveStep() {
    $(".shipment_head li").removeClass("active");
    $(".shipment_head li:nth-child(" + (currentStep + 1) + ")").addClass(
      "active"
    );
  }

  // Function to show the current step and hide the rest
  function showCurrentStep() {
    $(".step").hide();
    $("#step" + currentStep).show();
  }


  // Custom logic for each step
  let activeStepIndex = -1;
  let activeStepIndexStep3 = 0;
  function handleStepLogic(step) {
    switch (step) {
      case 1:
        // Step 1 logic
        $(".basic_details_ticks li:eq(1)").removeClass("active");

        var isValid = true;
        var industry_details = $("#industry_type").val(); 
        var track_id = $("#track_id").val(); 
        var shipment_date = $("#datepicker").val(); 
        var orgin_port = $("#orgin_port").val();
        var destinaton_port = $("#destinaton_port").val();
        var goods_shipped = $("#gship").val(); 
        var purchasehs_order = $("#purchasehs_order").val();
        var shipment_quantity = $("#shipment_quantity").val();
        var raw_country_origin = $("#raw_country_origin").val();
  
        if (track_id.trim() == "") {
          $("#track-id-error").text("This field is required.");
          isValid = false;
        } else {
          $("#track-id-error").text("");
        }

        if (orgin_port.trim() == "") {
          $("#orgin-port-error").text("This field is required.");
          isValid = false;
        } else {
          $("#orgin-port-error").text("");
        }
  
        if (destinaton_port.trim() == "") {
          $("#destinaton-port-error").text("This field is required.");
          isValid = false;
        } else {
          $("#destinaton-port-error").text("");
        }

        // Remove previous error classes
        $('.entry_line_file_info input, .entry_line_file_info select').removeClass('border_error');

        $('.entry_line_file_info tbody tr').each(function () {
          $(this).find('input, select').each(function () {
            if ($(this).val() === '') {
              $(this).addClass('border_error');
              isValid = false;
            }
          });
        });
        
        if(isValid == false){
           return isValid;
        }

        // Submit the form using AJAX
        $(".basic_details_ticks li:eq(1)").addClass("active");

        /************Start Step 2*********/

        $('.tabs').empty();
        $('.show_tabs').empty();

        $('table.entry_line_file_info tbody tr').each(function(index) {
            var entryLineValue = $(this).find('.entry_line').val();
            var tabButton = $(`<div class="tab-button" data-tab="tab${index + 1}" data-entry="entry_${index}">${entryLineValue}</div>`);
            var tabContent = $(`<div class="tab-content row" id="tab${index + 1}" data-entry="entry_${index}">
              <div class="col-lg-3 col-sm-12">
                <div class="detail_info left_section"></div>
              </div>
              <div class="col-lg-6 right_ship_detail mt-3">
                <div class="guide_info">
                  <h3>Guidelines</h3>
                  <ul>
                    <li><b>Choose your documents - </b><span>Select the documents from all your manufacturing steps.</span></li>
                    <li><b>Tag by manufacturing step - </b><span>Tag each document by it's specific manufacturing stage.</span></li>
                  </ul>
                </div>
                <div class="bg-gray right_section"></div>
              </div>
              <div class="col-lg-3">
                <div class="bg-gray mb-3 main_preview preview_section"></div>
              </div>
            `);
            $('.tabs').append(tabButton);
            $('.show_tabs').append(tabContent);
        });

        tabs();

        let industryType = $("#industry_type").val();
        getIndustryData(industryType);

        /************End Step 2*********/
        
        
        /************Start Preview Set Step 5*********/ 

        var industry_details_text = $("#industry_type").find("option:selected").text();
        var orgin_port_text = $("#orgin_port").find("option:selected").text();
        var destinaton_port_text = $("#destinaton_port").find("option:selected").text();
        var raw_country_origin_text = $("#raw_country_origin").find("option:selected").text();

        $(".prv_step_5_industry_details").text(industry_details_text);
        $(".prv_step_5_reference_no").text(track_id);
        $(".prv_step_5_shipment_date").text(shipment_date);
        $(".prv_step_5_destinaton_port").text(destinaton_port_text);
        $(".prv_step_5_purchase_order").text(purchasehs_order);
        $(".prv_step_5_origin_port").text(orgin_port_text);
        $(".prv_step_5_goods").text(goods_shipped);
        $(".prv_step_5_shipment_quan").text(shipment_quantity);
        $(".prv_step_5_material_origin").text(raw_country_origin_text);

        /************End Preview Set Step 5************/
        break;
      case 2:
        // Step 2 logic

        /******************************Start Check vaildtion step 2***************************************/

        var visibleTables = $('.right_section table:visible');
        var isAllChecked = true;

        visibleTables.each(function() {
          var isChecked = $(this).find('input[type="checkbox"]:checked').length > 0;
          var documentTitleCheck = $(this).find('.document_title').val();
          if (!isChecked) {
            isAllChecked = false;
            return false;
          }
        });


        var valid = true;

        $(".document_info").each(function() {
          var checkbox = $(this).find("input[type='checkbox']");
          var tagError = $(this).closest("tr").find(".tag_error_msg");
          var documentTitleError = $(this).closest("tr").find(".document_title_msg");
          if (checkbox.prop("checked")) {
            var documentTitle = $(this).closest("tr").find(".document_title").val();
            var selectedOptions = $(this).closest("tr").find(".option input:checked");

            if (documentTitle == "") {
              valid = false;
              documentTitleError.text("This field is required").show();
            } else {
              documentTitleError.text("").hide();
            }

            if (selectedOptions.length === 0) {
              valid = false;
              tagError.text("This field is required").show();
            } else {
              tagError.text("").hide();
            }

          } else {
            documentTitleError.text("").hide();
            tagError.text("").hide();
          }
        });


          let isUploadFileValid1 = true;
        $('.right_ship_detail table:visible').find('.fileInput').each(function() {
            if ($(this)[0].files.length === 0) {
              isUploadFileValid1 = false;
                // const errorMsg = 'This field is required';
                // $(this).siblings('.upload_file_msg').text(errorMsg).show();
                $(this).addClass("error_upload");
            }
            else {
              // $(this).siblings('.upload_file_msg').text("").hide();
              $(this).removeClass("error_upload");
            }
        });


        if(!valid || !isUploadFileValid1){
          return false;
        }

        if (isAllChecked) {
          $('.alert').hide();
          let tableBlockCount = $('.right_section table:hidden').length;
          if (tableBlockCount) {
            var nextTable = $('table:hidden').first();
            nextTable.show();
            activeStepIndex++; // Increment the active step index
            $('.left_section li').eq(activeStepIndex).addClass('active');
            return false;
          }
          activeStepIndex++; // Increment the active step index
          $('.left_section li').eq(activeStepIndex).addClass('active');
        }else{
          $('.alert').fadeIn();
          setTimeout(function(){
            $('.alert').fadeOut();
          }, 2000);
          return false;
        }
        slider();

        $(".file-name").each(function(index){
          let par_cat_title = $(this).closest(".preview__info").find(".preview_category_title").text().replace(/\s/g, '-');
          let sub_cat_title = $(this).closest(".preview_group").find(".cont_type").find("label").text().replace(/[\s/]/g, '-').replace(/-+/g, '-');
          let final_title = $(this).closest(".tags_info").find(".tag_title").text().replace(/\s/g, '-');
          let url = par_cat_title+"/"+sub_cat_title+"/"+final_title+"/";
          $(this).attr("data-fileindex", index);
          $(this).attr("data-url", url);
        });


        /******************************End Check vaildtion step 2***************************************/
       $("#step3 .preview_section_step_3").html($(".preview_section").html());
       window.scrollTo(0, 0);
        //console.log("Step 2 logic executed");
        break;
      case 3:
        // Step 3 logic

        /*let isUploadFileValid = true;
        $('.right_section_step_3 table:visible').find('.fileInput').each(function() {
            if ($(this)[0].files.length === 0) {
              isUploadFileValid = false;
                const errorMsg = 'This field is required';
                $(this).siblings('.upload_file_msg').text(errorMsg).show();
            }
            else {
              $(this).siblings('.upload_file_msg').text("").hide();
            }
        });

        if (!isUploadFileValid) {
          return false;
        }else{
          $('.left_section_step_3 li').eq(activeStepIndexStep3).addClass('active');
          activeStepIndexStep3++;
        }

        let tableBlockCountStep3 = $('.right_section_step_3 table:hidden').length;
        if (tableBlockCountStep3) {
          var nextTable = $('.right_section_step_3 table:hidden').first();
          nextTable.show();
          return false;
        } */

        var dataSkip = $(this).attr("data-skip");

        if(dataSkip != "skip"){
          let isUploadFileValid = true;
          if($('.box_info').length > 0){
            $('.box_info').each(function() {
                var entityName = $(this).find('input[name="entity_name"]');
                var address = $(this).find('input[name="address"]');
                var country = $(this).find('.bulid_country').val();
                var remark = $(this).find('input[name="remark"]').val();
                var from = $(this).find('.start-date').val();
                var to = $(this).find('.end-date').val();
                if (entityName.val().trim() === '' || address.val().trim() === '' || country.trim() === '' || remark.trim() === '' || from.trim() === '' || to.trim() === '') {
                    isUploadFileValid = false;
                    $(this).addClass('map_error');
                } else {
                    $(this).removeClass('map_error');
                }
            });
          }else{
            isUploadFileValid = false;
            $('.step_map_alert').fadeIn();
            setTimeout(function(){
              $('.step_map_alert').fadeOut();
            }, 2000);
          }
  
          if (!isUploadFileValid) {
            return false;
          }  
        }else{
          $(".box_bottom").find(".fa-trash").click();
        }

      


        $("#step4 .preview_upload_section_list").html($(".preview_section_step_3").html());
        previewBuildProMap();
        //$("#step4 .preview_section_step_4").html($(".preview_section_step_3").html());
        // console.log("Step 3 logic executed");
        break;
      case 4:
        // Step 4 logic
        $("#step5 .preview_upload_section_list").html($(".preview_section_step_3").html());
        //console.log("Step 4 logic executed");
        break;
      case 5:
        // Step 5 logic
       // console.log("Step 5 logic executed");
        break;
      case 6:
        // Step 6 logic
        console.log("Step 6 logic executed");
        break;
      default:
        break;
    }
    currentStep++;
  }

  // Function to handle next button click
  $(document).on("click", ".next", function () {
    if (currentStep < totalSteps) {
     // handleStepLogic(currentStep);
      handleStepLogic.call(this, currentStep);

      updateActiveStep();
      showCurrentStep();
    }
  });

  // Function to handle previous button click
  $(document).on("click", ".previous", function () {
    if (currentStep > 1) {
      currentStep--;
      updateActiveStep();
      showCurrentStep();
    }
  });

  // Initialize the form with the second step active and the first step displayed
  currentStep = 1; // Set currentStep to 1
  updateActiveStep();
  showCurrentStep();
});

$(document).on("change", ".fileInput", function (event) {
  const selectedFiles = event.target.files;

  if (selectedFiles.length > 0) {
    const $closestDocumentFileInfo = $(this).closest('.document_file_info');
    const uploadTagValue = $closestDocumentFileInfo.find('.upload_tags').val().trim();
    const primaryInputValue = $closestDocumentFileInfo.closest("tr").find('.document_title').val();
    const $previewInfo = $('.preview__info');

    const $matchingTagTitle = $previewInfo.find('.tag_title:contains(' + uploadTagValue + ')');
    let matchVal = primaryInputValue +"_"+ uploadTagValue;

    if ($matchingTagTitle.length > 0) {
      const $ul = $matchingTagTitle.closest('.tags_info').find('ul[data-cont-type="' + matchVal + '"]');
      
      // Clear existing <li> elements
      $ul.empty();
      
      // Append new <li> elements with file icons and names
      for (let i = 0; i < selectedFiles.length; i++) {
        const file = selectedFiles[i];
        const fileName = file.name;
        const fileExtension = fileName.split('.').pop().toLowerCase();
        const iconSrc = getFileIconElement(fileExtension);

        const $fileIcon = $('<div>').addClass('file-icon').append($('<img>').attr('src', iconSrc).addClass('file-icon'));
        const $fileName = $('<div  class="file-name">').text(fileName);
        const $fileNameDiv = $('<li>').append($fileIcon, $fileName);
        $ul.append($fileNameDiv);
      }
    }
  }
});

function getFileIconElement(fileName) {
    const extension = fileName.split('.').pop().toLowerCase();
    let iconSrc = '';

    switch (extension) {
        case 'jpg':
          iconSrc = '/images/share/jpg-icon.png';
          break;
        case 'png':
          iconSrc = '/images/share/png-icon.png';
          break;
        case 'gif':
            iconSrc = '/images/share/gif-icon.png';
            break;
        case 'pdf':
            iconSrc = '/images/share/pdf-icon.png';
            break;
        case 'doc':
          iconSrc = '/images/share/doc-icon.png';
          break;
        case 'docx':
            iconSrc = '/images/share/docx-icon.png';
            break;
        case 'xlsx':
            iconSrc = '/images/share/xlsx-icon.png';
            break;
        // Add more cases for other file types
        default:
            iconSrc = '/images/share/default-icon.png'; 
    }

    return iconSrc;
}


$(document).on("change", ".company_user", function (event) {
  $(".preview_share_section_list").empty();
  $(".company_user:checked").each(function() {
    var labelHTML = $(this).next("label").html();
    $(".preview_share_section_list").append('<li>' + labelHTML + '</li>');
  });
});

$(document).on("click", ".close_add_new_shipment", function (event) {
  location.reload();
});

/************************Start Add new shipment **************************/

function handleFormSubmission(event) {
  event.preventDefault();
  $(event.originalEvent.submitter).prop("disabled", true).html('<div class="fa fa-circle-o-notch fa-spin" style="font-size: 30px;"></div>');;
  let status = $(event.originalEvent.submitter).data("status");
  let stepStatus = $(event.originalEvent.submitter).attr("data-step");
  let updateid = $(event.originalEvent.submitter).attr("data-updateid");
  let formData = new FormData(jQuery("#add_new_shipment")[0]);

  let step3UploadData = [];
  $(".right_section .upload_tags").each(function () {
    let upload_tags = $(this).val();
    let upload_document_type = $(this).closest("tr").find(".text_primary").val();
    let upload_category_title_id = $(this).closest("tr").find(".upload_category_title_id").val();
    let upload_category_title = $(this).closest("tr").find(".upload_category_title").val();
    let upload_document_title_id = $(this).closest("tr").find(".upload_document_title_id").val();
    let upload_document_title = $(this).closest("tr").find(".upload_document_title").val();
    let upload_match = `${upload_document_title.replace(/ /gi, '_')}_${upload_tags.replace(/ /gi, '_')}`;

    step3UploadData.push({ upload_document_type: upload_document_type, upload_category_title_id: upload_category_title_id, upload_category_title: upload_category_title, upload_document_title_id: upload_document_title_id, upload_document_title: upload_document_title, upload_tags: upload_tags, upload_match: upload_match});

  });

  var buildProductionMap = [];

  $('.box_info').each(function() {
      var title = $(this).closest('.box_container').find('.top_head h3').text().replace(/\d+\.\s*/, '');
      var entityName = $(this).find('input[name="entity_name"]').val();
      var address = $(this).find('input[name="address"]').val();
      var country = $(this).find('.bulid_country').val();
      var remark = $(this).find('input[name="remark"]').val();
      var from = $(this).find('.start-date').val();
      var to = $(this).find('.end-date').val();
      var selected_options = [];
  
      $(this).find('.option-map input:checked').each(function() {
          var spanValue = $(this).siblings('label').find('span').text();
          var buildindex = $(this).siblings('label').find('span').attr("data-buildindex");
          var url = $(this).siblings('label').find('span').attr("data-url");
          selected_options.push({
            name: spanValue,
            buildindex: buildindex,
            url: url
        });
      });
  
      if (entityName.trim() !== '') {
          var item = {
              "title": title,
              "entity_name": entityName,
              "address": address,
              "country": country,
              "remark": remark,
              "from": from,
              "to": to,
              "selected_options": selected_options
          };
  
          // Check for duplicates before pushing
          var isDuplicate = buildProductionMap.some(function(existingItem) {
              return existingItem.title === item.title && existingItem.entity_name === item.entity_name;
          });
  
          if (!isDuplicate) {
              buildProductionMap.push(item);
          }
      }
  });
  
  $('.box_container').each(function() {
      var title = $(this).find('.top_head h3').text().replace(/\d+\.\s*/, '');
      var entityName = $(this).find('input[name="entity_name"]').val();
  
      if (entityName !== '') {
          var item = {
              "title": title,
              "entity_name": entityName,
              "address": "",
              "remark": "",
              "selected_options": []
          };
  
          // Check for duplicates before pushing
          var isDuplicate = buildProductionMap.some(function(existingItem) {
              return existingItem.title === item.title && existingItem.entity_name === item.entity_name;
          });
  
          if (!isDuplicate) {
              buildProductionMap.push(item);
          }
      }
  });
  
   console.log(JSON.stringify(buildProductionMap, null, 3));

  formData.append("status", status);
  formData.append("step_status", stepStatus);
  formData.append("updateid", updateid);
  formData.append("step_2_data", JSON.stringify(step3UploadData));
  formData.append("buildProductionMap", JSON.stringify(buildProductionMap));

  jQuery.ajax({
    headers: {
      "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
    },
    url: "/company/save-shipment",
    type: "post",
    data: formData,
    processData: false,
    contentType: false,
    success: function (data) {
      if(status == "publish"){
        $(".step4.next").click();
        $(".share").attr("data-share", data[0].insertId);
        $(".share").attr("data-factory", $('input[name="factory_id"]').val());
        $(".share").attr("data-industry", $("#industry_type").val());
      }else if(status == "draft"){
        show_msg("Success", "success__err", "#46c93a", "Your draft has been saved successfully");
        setTimeout(function(){
          window.location.href = '/company/edit-shipment/'+data;
        }, 2000);
      }
    },
  });
}

$(document).on("submit", "#add_new_shipment", function (event) {
   handleFormSubmission(event);
});
$(document).on("click", ".share", function (event) {

    var companyUserValues = [];
    $(".company_user:checked").each(function() {
        companyUserValues.push($(this).val());
    });

    var shareData = $(this).data("share");
    var industryData = $(this).data("industry");
    var factoryData = $(this).data("factory");

    var sendData = {
        share_company_id: companyUserValues,
        share: shareData,
        industry: industryData,
        factory: factoryData
    };

    $.ajax({
        headers: {
          "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
        },
        type: "POST",
        url: "/company/store-share-data", 
        data: sendData,
        success: function(data) {
          if(data){
            window.location.href = '/view-shipment-documents?id='+data; 
          }
        }
    });
});


/************************End Add new shipment **************************/

function updateShareAllCheckbox() {
  var allCompanyUsersChecked = $('.company_user:not(:checked)').length === 0;
  $('.share_all_checkbox').prop('checked', allCompanyUsersChecked);
}

$(document).on("click", ".share_all_checkbox", function () {
  if ($(this).prop('checked')) {
      $("#share_table tbody tr").addClass('active');
  } else {
    $("#share_table tbody tr").removeClass('active');
  }
  var isChecked = $(this).prop('checked');
  $('.company_user').prop('checked', isChecked);
});

$(document).on("click", ".company_user", function () {
  if ($(this).prop('checked')) {
      $(this).closest("tr").addClass('active');
  } else {
    $(this).closest("tr").removeClass('active');
  }
  var isChecked = $(this).prop('checked');
  $(this).prop('checked', isChecked);

  updateShareAllCheckbox();
});
